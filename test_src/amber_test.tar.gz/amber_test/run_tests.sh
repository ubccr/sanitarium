#!/bin/sh
#
# Amber tests based on the tutorial:
#
#    https://ambermd.org/tutorials/basic/tutorial0/index.php
#
#
# cd to the dir containing this script
cd "$(dirname "$(readlink -f "$0")")"
#
#
sander="sander"
echo "${1}" | grep -i -q "cuda" && sander="sander.quick.cuda"
#
#
# Load a force field to describe the potential energy of alanine dipeptide
# using the AMBER force field FF20SB for proteins with tleap
echo "Running tleap"
tleap -f tleap.commands
if [ "$?" != "0" ]
then
  echo "tleap run failed - bailing" >&2
  exit 1
fi
echo "tleap run complete"
echo 

# Run the minimization of alanine dipeptide with sander
echo "Running ${sander} to minimize the alanine dipeptide"
${sander} -O -i 01_Min.in -o 01_Min.out -p parm7 -c rst7 -r 01_Min.ncrst \
 -inf 01_Min.mdinfo
if [ "$?" != "0" ]
then
  echo "${sander} run to minimize the alanine dipeptide failed - bailing" >&2
  exit 1
fi
echo "${sander} run to minimize the alanine dipeptide complete"
echo

# Run the heating of alanine dipeptide with sander
echo "Running ${sander} for the heating of alanine dipeptide"
${sander} -O -i 02_Heat.in -o 02_Heat.out -p parm7 -c 01_Min.ncrst \
 -r 02_Heat.ncrst -x 02_Heat.nc -inf 02_Heat.mdinfo
if [ "$?" != "0" ]
then
  echo "${sander} run for the heating of alanine dipeptide failed - bailing" >&2
  exit 1
fi
echo "${sander} run for the heating of alanine dipeptide complete"
echo


###
### NOTE: pmemd run takes too long for a Pavilion test
###
###
#### Run the production MD of alanine dipeptide with pmemd.
###echo "Running pmemd for the production MD of alanine dipeptide"
###pmemd -O -i 03_Prod.in -o 03_Prod.out -p parm7 -c 02_Heat.ncrst \ 
### -r 03_Prod.ncrst -x 03_Prod.nc -inf 03_Prod.info
###if [ "$?" != "0" ]
###then
###  echo "pmemd run for the production MD of alanine dipeptide failed - bailing" >&2
###  exit 1
###fi
###echo "pmemd run for the production MD of alanine dipeptide complete"
###
