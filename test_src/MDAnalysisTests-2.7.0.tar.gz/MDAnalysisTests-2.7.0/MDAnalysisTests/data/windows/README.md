Avast, here be scurvy ascii files with DOS line endings.

They be here for the testing of reading these on different platforrrrms.

See related issues #2125 and #2128 on the good ship Github.