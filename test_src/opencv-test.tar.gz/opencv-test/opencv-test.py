import numpy as np
import cv2 as cv
img = cv.imread('roi.jpg')
assert img is not None, "file could not be read, check with os.path.exists()"
print(img.size)
